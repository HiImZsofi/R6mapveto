﻿using System;
using System.IO;
using System.Collections.Generic;

namespace mapvetoR6
{
    class Program
    {
        static List<string> mappool = new List<string>();
        static void mapFillUp()
        {
            StreamReader sr = new StreamReader("mappool.txt");
            string sor;
            while (!sr.EndOfStream)
            {
                sor = sr.ReadLine();
                mappool.Add(sor);
            }
            sr.Close();
        }

        static List<int> sorsoltak()
        {
            List<int> index = new List<int>();
            Random r = new Random();
            int elso = r.Next(0, 12);
            int masodik, harmadik;
            do
            {
                masodik = r.Next(0, 12);
                harmadik = r.Next(0, 12);

            } while (masodik == elso || elso == harmadik || masodik == harmadik);
            index.Add(elso);
            index.Add(masodik);
            index.Add(harmadik);
            return index;
        }    

        static string bluebann(string a, string b, string c)
        {
            string blueBan = " ";
            Console.WriteLine("Blue team válaszd ki melyik pályát szeretnéd bannolni (1,2,3)");
            int blueban = Convert.ToInt32(Console.ReadLine());
            if (blueban == 1)
            {
                blueBan = a;
            }
            else if (blueban == 2)
            {
                blueBan = b;
            }
            else if (blueban == 3)
            {
                blueBan = c;
            }
            return blueBan;
        }

        static string orangebann(string a, string b, string c)
        {
            string orangeBan = " ";
            Console.WriteLine("Orange team válaszd ki melyik pályát szeretnéd bannolni (1,2,3)");
            int orangeban = Convert.ToInt32(Console.ReadLine());
            if (orangeban == 1)
            {
                orangeBan = a;
            }
            else if (orangeban == 2)
            {
                orangeBan = b;
            }
            else if (orangeban == 3)
            {
                orangeBan = c;
            }
            return orangeBan;
        }

        static void Main(string[] args)
        {
            Console.WriteLine();
            mapFillUp();
            List<int> kapottszamok = sorsoltak();
            string map1, map2, map3;
            map1 = mappool[kapottszamok[0]];
            map2 = mappool[kapottszamok[1]];
            map3 = mappool[kapottszamok[2]];
            Console.WriteLine(map1 + "         " + map2 + "         " + map3);
            string kekoldal = bluebann(map1, map2, map3);
            string sargaoldal = orangebann(map1, map2, map3);
            string vegsomap = " ";
            if (kekoldal == sargaoldal)
            {
                Random r2 = new Random();
                int final = r2.Next(1, 3);
                if (kekoldal == map1)
                {
                    if (final == 1)
                    {
                        vegsomap = map2;
                    }
                    else
                    {
                        vegsomap = map3;
                    }
                }
                else if (kekoldal == map2)
                {
                    if (final == 1)
                    {
                        vegsomap = map1;
                    }
                    else
                    {
                        vegsomap = map3;
                    }
                }
                else if (kekoldal == map3)
                {
                    if (final == 1)
                    {
                        vegsomap = map1;
                    }
                    else
                    {
                        vegsomap = map2;
                    }
                }
            }
            else
            {
                if (kekoldal == map1 && sargaoldal == map2)
                {
                    vegsomap = map3;
                }
                else if (kekoldal == map1 && sargaoldal == map3)
                {
                    vegsomap = map2;
                }
                else if (kekoldal == map2 && sargaoldal == map3)
                {
                    vegsomap = map1;
                }
                else if (kekoldal == map2 && sargaoldal == map1)
                {
                    vegsomap = map3;
                }
                else if (kekoldal == map3 && sargaoldal == map1)
                {
                    vegsomap = map2;
                }
                else if (kekoldal == map3 && sargaoldal == map2)
                {
                    vegsomap = map1;
                }
            }
            Console.WriteLine("A végső map: " + vegsomap);
            Console.ReadKey();
        }
    }
}
